========================================================================
    CONSOLE APPLICATION : multiOTP C++ launcher
========================================================================
Launcher for the multiOTP open source embedded CLI package

multiOTP C++ launcher - Strong two-factor authentication solution
https://www.multiotp.net

Visit http://forum.multiotp.net/ for additional support.

Donation are always welcome! Please check https://www.multiotp.net
and you will find the magic button ;-)

The multiOTP C++ launcher is simply used to launch PHP
and run multiotp.windows.php with the provided arguments.

@author    Andre Liechti, SysCo systemes de communication sa, <info@multiotp.net>
@version   5.9.5.1
@date      2022-11-11
@since     2016-12-08
@copyright (c) 2010-2022 SysCo systemes de communication sa
@copyright GNU Lesser General Public License

LICENCE

Copyright (c) 2010-2022 SysCo systemes de communication sa
SysCo (tm) is a trademark of SysCo systemes de communication sa
(http://www.sysco.ch)
All rights reserved.

This file is part of the multiOTP open source project.

multiOTP open source project is free software; you can redistribute it
and/or modify it under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

multiOTP open source project is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with multiOTP open source project.
If not, see <http://www.gnu.org/licenses/>.

/////////////////////////////////////////////////////////////////////////////
launcher.vcxproj
    This is the main project file for the VC++ project 

launcher.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named launcher.pch and a precompiled types file named StdAfx.obj.
